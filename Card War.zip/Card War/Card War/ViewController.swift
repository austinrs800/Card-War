//
//  ViewController.swift
//  Card War
//  DISCLAIMER: This app is developed for an educational project.
//  Certain materials are included under the fair use exemption of the U.S. Copyright Law and have been prepared according to the multimedia fair use guidelines and are restricted from further use
//  Created by Austin Roy-Stewart on 10/13/22.
//

import UIKit
import AVKit

class ViewController: UIViewController {

    var mySound:AVAudioPlayer!
    @IBOutlet weak var didTapHowTo: UILabel!
   
        
        
        
    @IBOutlet weak var TIElbl: UILabel!
    @IBOutlet weak var CPUCardimg: UIImageView!
    @IBOutlet weak var playerCardimg: UIImageView!
    @IBOutlet weak var playerScorelbl: UILabel!
    @IBOutlet weak var CPUScorelbl: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        TIElbl.alpha = 0
        let soundObj = URL(fileURLWithPath: Bundle.main.path(forResource: "shuffling-cards-1", ofType: "mp3")!)
        mySound = try? AVAudioPlayer(contentsOf: soundObj)
    }
    var playerScore = 0
    var CPUScore = 0
    let cardList = [2: "2", 3: "3", 4: "4", 5: "5", 6: "6", 7: "7", 8: "8", 9: "9", 10: "10", 11: "jack", 12: "queen", 13: "king", 14: "ace"]
    //this function will deal the players cards and change the images based on what the cards were. We will also update scores.
    var playCount = 0
    func gamePlay(){
        playerCardimg.alpha = 0
        CPUCardimg.alpha = 0
        let playerCard = cardList.randomElement()
        playerCardimg.image = UIImage(named: "card" + playerCard!.value)
        UIView.animate(withDuration: 2.0, animations: { self.playerCardimg.alpha = 1})
        
        let CPUCard = cardList.randomElement()
        CPUCardimg.image = UIImage(named: "card" + CPUCard!.value)
        UIView.animate(withDuration: 2.0, animations: { self.CPUCardimg.alpha = 1})
        
        if playerCard!.key > CPUCard!.key{
            playerScore += (1+playCount)
            playerScorelbl.text = String(playerScore)
            playCount = 0
        }
        else if CPUCard!.key > playerCard!.key{
            CPUScore += (1+playCount)
            CPUScorelbl.text = String(CPUScore)
            playCount = 0
        }
        else if playerCard!.key == CPUCard!.key{
            playCount += 1
            UIView.animate(withDuration: 3.0, animations: {self.TIElbl.alpha = 1})
            UIView.animate(withDuration: 3.0, animations: {self.TIElbl.alpha = 0})
            gamePlay()
        }
    }
    
    @IBAction func btnRules(_ sender: Any) {
        let browsingApp = UIApplication.shared
        let url  = URL(string: "https://www.bicyclecards.com/how-to-play/war/")
        browsingApp.open(url!)
    }
    @IBAction func playButtonPress(_ sender: Any) {
        gamePlay()
        mySound.play()
    }
}

